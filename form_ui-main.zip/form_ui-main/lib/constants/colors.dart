import 'dart:ui';

class AppColors{
  static const Color primary = Color(0xff561bd3);
}