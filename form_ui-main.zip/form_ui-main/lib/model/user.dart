class User{
  late String name;
  late String phone;
  late String email;
}