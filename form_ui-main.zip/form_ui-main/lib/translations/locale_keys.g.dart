// DO NOT EDIT. This is code generated via package:easy_localization/generate.dart

abstract class  LocaleKeys {
  static const register = 'register';
  static const inputusername = 'inputusername';
  static const inputphone = 'inputphone';
  static const inputpassword = 'inputpassword';
  static const buttonSubmit = 'buttonSubmit';
  static const haveacc = 'haveacc';
  static const buttonSign = 'buttonSign';
  static const welcome = 'welcome';
  static const noAcc = 'noAcc';

}
